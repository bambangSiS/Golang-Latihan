# golang-ajax
Simple Web App that allows to manage Customers table
(Create-Read-Update)
- GoLang with html/template
- PostgreSQL
- Ajax-JSON
- JQuery

Features:
- Single screen app
- Multisession data control
- Multilanguage
