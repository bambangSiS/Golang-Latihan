create table users (
  username text primary key,
  password text
);