Bluz, a lightweight PHP Framework
=================================
Easy to setup, easy to use.

[![Gitter](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/bluzphp/main)

## Achievements
[![PHP >= 7.2+](https://img.shields.io/packagist/php-v/bluzphp/framework.svg?style=flat)](https://php.net/)

[![Latest Stable Version](https://img.shields.io/packagist/v/bluzphp/framework.svg?label=version&style=flat)](https://packagist.org/packages/bluzphp/framework)

[![Build Status](https://img.shields.io/travis/bluzphp/framework/master.svg?style=flat)](https://travis-ci.org/bluzphp/framework)

[![Scrutinizer Code Quality](https://img.shields.io/scrutinizer/g/bluzphp/framework.svg?style=flat)](https://scrutinizer-ci.com/g/bluzphp/framework/)

[![Coverage Status](https://img.shields.io/coveralls/bluzphp/framework/master.svg?style=flat)](https://coveralls.io/r/bluzphp/framework?branch=master)

[![Total Downloads](https://img.shields.io/packagist/dt/bluzphp/framework.svg?style=flat)](https://packagist.org/packages/bluzphp/framework)

[![License](https://img.shields.io/packagist/l/bluzphp/framework.svg?style=flat)](https://packagist.org/packages/bluzphp/framework)

## Installation

The best way is setup the [skeleton][1] application

## Usage

In our [wiki][2] you can find description of every package.  
Auto-generating documentation is available at the http://bluzphp.github.io/

## License

The project is developed by [NIX Solutions][3] PHP team and distributed under [MIT LICENSE][4]

[1]: https://github.com/bluzphp/skeleton
[2]: https://github.com/bluzphp/framework/wiki
[3]: http://nixsolutions.com
[4]: https://raw.github.com/bluzphp/framework/master/LICENSE.md

