<?php
/**
 * @copyright Bluz PHP Team
 * @link      https://github.com/bluzphp/framework
 */

/**
 * Example of invalid helper
 *
 * @author   Anton Shevchuk
 * @created  14.01.14 11:39
 */
return rand(1, 42);
