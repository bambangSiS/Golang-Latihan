<?php
/**
 * @copyright Bluz PHP Team
 * @link      https://github.com/bluzphp/framework
 */

/**
 * Example of helpers
 *
 * @author   Anton Shevchuk
 * @created  14.01.14 11:39
 *
 * @param $argument
 *
 * @return mixed
 */
return function ($argument) {
    return $argument;
};
