<?php
/**
 * Index configuration for default environment
 *
 * @author   Anton Shevchuk
 * @created  19.09.2014 15:09
 */
return [
    'foo' => 'bar',
    'qux' => 'bar'
];
