<?php
return [
    'section1' => 'default',
    'section2' => [],
    'section3' => [],
];
