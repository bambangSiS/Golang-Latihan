<?php
return [
    'section1' => 1,
    'section2' => [
        'subsection21' => 21,
        'subsection22' => 22
    ],
    'section3' => [
        'subsection31' => 31,
        'subsection32' => 32
    ],
];
