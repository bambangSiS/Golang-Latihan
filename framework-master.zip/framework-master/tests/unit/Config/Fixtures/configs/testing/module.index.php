<?php
/**
 * Index configuration for testing environment
 *
 * @author   Anton Shevchuk
 * @created  19.09.2014 15:10
 */
return [
    'foo' => 'baz'
];
