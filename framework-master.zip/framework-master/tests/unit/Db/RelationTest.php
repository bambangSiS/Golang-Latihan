<?php
/**
 * @copyright Bluz PHP Team
 * @link      https://github.com/bluzphp/framework
 */

namespace Bluz\Tests\Db;

use Bluz\Tests\FrameworkTestCase;

/**
 * Test class for Db\Relations
 */
class RelationTest extends FrameworkTestCase
{
    /**
     * setUp
     */
    public function setUp()
    {
    }

    /**
     * tearDown
     */
    public function tearDown()
    {
    }

    /**
     * testRelationOneToOne
     */
    public function testRelationOneToOne()
    {
        self::markTestIncomplete(
            'This test has not been implemented yet.'
        );
    }

    /**
     * testRelationManyToMany
     */
    public function testRelationManyToMany()
    {
        self::markTestIncomplete(
            'This test has not been implemented yet.'
        );
    }
}
