<?php
/**
 * @copyright Bluz PHP Team
 * @link      https://github.com/bluzphp/framework
 */

namespace Bluz\Tests\Fixtures\Controllers;

use Bluz\Controller\Controller;

/**
 * @return array
 */
return function ($a, $b, $c = null) {
    /**
     * @var Controller $this
     */
    return [];
};
