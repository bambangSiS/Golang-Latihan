<?php
/**
 * @copyright Bluz PHP Team
 * @link      https://github.com/bluzphp/skeleton
 */

/**
 * @namespace
 */

namespace Bluz\Tests\Fixtures\Crud;

use Bluz\Crud\Table;

/**
 * Crud based on Db\Table
 *
 * @package  Bluz\Tests\Fixtures
 *
 * @author   Anton Shevchuk
 * @created  03.09.12 13:11
 */
class TableCrud extends Table
{
    /**
     * Reset Table
     *
     * @return void
     */
    public function resetTable()
    {
        $this->table = null;
    }
}
