<?php
/**
 * Request configuration
 *
 * @link https://github.com/bluzphp/framework/wiki/Request
 * @return array
 */
return [];
