<?php
/**
 * Logger
 *
 * @link https://github.com/bluzphp/framework/wiki/Logger
 * @return bool
 */
return getenv('BLUZ_LOG');
