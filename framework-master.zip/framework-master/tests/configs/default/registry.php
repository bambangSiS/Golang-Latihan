<?php
/**
 * Registry data
 *
 * @link https://github.com/bluzphp/framework/wiki/Registry
 * @return array
 */
return [];
