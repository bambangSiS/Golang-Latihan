<?php
/**
 * Temporary files for tests
 *
 * @return array
 */
return [
    'image1' => PATH_ROOT . '/tests/src/Fixtures/Http/test.jpg',
    'image2' => PATH_ROOT . '/tests/src/Fixtures/Http/test1.jpg'
];
