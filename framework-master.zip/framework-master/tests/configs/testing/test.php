<?php
/**
 * Test
 *
 * @return array
 */
return [
    'foo' => 'bar'
];
