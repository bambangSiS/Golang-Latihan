<?php
/**
 * @copyright Bluz PHP Team
 * @link      https://github.com/bluzphp/framework
 */

/**
 * Example of empty test controller
 *
 * @author   Anton Shevchuk
 */

namespace Application;

/**
 * @return bool
 */
return function () {
    return false;
};
